<?php
/**
 * Created by PhpStorm.
 * User: Narendra
 * Date: 3/25/2015
 * Time: 3:47 PM
 */




/**
 * Server Database configuration
 */
define('SERVER_DB_USERNAME', 'agicent_dev');
define('SERVER_DB_PASSWORD', 'Agicent!123');
define('SERVER_DB_HOST', 'localhost');
define('SERVER_DB_NAME', 'agicent_dev_yve');




?>
